const KEY = 'loot_legends_save_v1';

export function loadSave() {
  try {
    return JSON.parse(localStorage.getItem(KEY)) || null;
  } catch {
    return null;
  }
}

export function saveGame(state) {
  localStorage.setItem(KEY, JSON.stringify({ ...state, savedAt: Date.now() }));
}

export function resetSave() {
  localStorage.removeItem(KEY);
}
