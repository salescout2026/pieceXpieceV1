import { useEffect, useState } from 'react';
import { BookOpen } from 'lucide-react';
import { Atlas } from './components/Atlas.jsx';
import { tabs, Hub, Quests, Pack, Profile, Journal } from './components/Screens.jsx';
import { loadSave, saveGame, resetSave } from './systems/save.js';
import './styles/app.css';

const defaultState = { screen:'hub', travel:{ moving:false, progress:.08 }, journal:['Arrived at Ashmoor Cross.'] };

export default function App(){
  const [state,setState]=useState(()=>loadSave()||defaultState);
  useEffect(()=>saveGame(state),[state]);
  useEffect(()=>{
    if(!state.travel.moving) return;
    const id=setInterval(()=>setState(s=>({ ...s, travel:{...s.travel, progress: Math.min(1, s.travel.progress+.006), moving: s.travel.progress<.994 }})),280);
    return()=>clearInterval(id);
  },[state.travel.moving]);
  const setScreen=(screen)=>setState(s=>({...s,screen}));
  const startTravel=(route)=>setState(s=>({...s, screen:'map', travel:{moving:true, progress:.08, route:route.id}, journal:[`Started ${route.name}.`,...s.journal]}));
  const Screen = state.screen==='hub'?Hub:state.screen==='quests'?Quests:state.screen==='pack'?Pack:state.screen==='profile'?Profile:state.screen==='journal'?Journal:null;
  return <main className="app-shell">
    <header className="topbar"><div className="seal">LL</div><div><h1>Loot <span>&</span> Legends</h1><p>{state.screen==='map'?'Living Atlas':'Questline Ledger'}</p></div><button onClick={()=>setScreen('journal')}><BookOpen/></button></header>
    <section className="content">{state.screen==='map'?<Atlas travel={state.travel} onTravel={startTravel}/>:<Screen/>}</section>
    <nav className="bottomnav">{tabs.map(([id,label,Icon])=><button key={id} className={state.screen===id?'active':''} onClick={()=>setScreen(id)}><Icon/><span>{label}</span></button>)}</nav>
  </main>
}
