export const WORLD = {
  player: { x: 34, y: 58, name: 'Ashmoor Cross' },
  regions: [
    { id:'greenreach', name:'Greenreach', x:15, y:22, w:50, h:45, tone:'meadow' },
    { id:'marsh', name:'Gallowfen Marsh', x:0, y:50, w:55, h:45, tone:'marsh' },
    { id:'greymarch', name:'The Greymarch', x:50, y:0, w:50, h:55, tone:'moor' },
    { id:'sunken', name:'The Sunken Reach', x:42, y:60, w:58, h:40, tone:'water' }
  ],
  mountains: [
    [8,15,6],[13,19,4],[19,16,5],[76,14,7],[86,19,5],[91,26,8]
  ],
  forests: Array.from({length:140}, (_,i)=>({
    x: 8 + ((i*19)%84),
    y: 18 + ((i*31)%65),
    s: 0.45 + ((i*7)%8)/20,
    dense: i%5===0
  })).filter(t => !(t.x>48 && t.y>35 && t.y<66)),
  rivers: [
    [[64,-4],[63,8],[62,21],[64,33],[61,45],[58,55],[59,70],[55,88],[51,104]],
    [[1,67],[10,62],[23,61],[33,65],[46,68],[59,70],[75,69],[101,72]],
    [[5,-2],[7,18],[11,35],[9,52],[5,70],[3,92]]
  ],
  roads: [
    { id:'silver', name:'Silver Road', danger:1, time:'2h 10m', reward:'+5% safer arrival', points:[[4,41],[18,45],[34,58],[48,52],[61,46],[72,40],[92,35]] },
    { id:'pilgrim', name:'Pilgrim Way', danger:2, time:'1h 35m', reward:'+10% clues', points:[[34,58],[36,48],[41,39],[49,30],[60,22],[72,18]] },
    { id:'ferry', name:'Ferryman’s Cut', danger:3, time:'1h 20m', reward:'+15% rare loot', points:[[34,58],[41,65],[55,72],[70,78],[87,85]] }
  ],
  locations: [
    {id:'ashmoor', name:'Ashmoor Cross', type:'town', x:34, y:58, discovered:true},
    {id:'chapel', name:'Chapel of the Last Ember', type:'quest', x:25, y:50, discovered:true},
    {id:'watch', name:'Old Watchtower', type:'ruin', x:84, y:28, discovered:true},
    {id:'bridge', name:'Greywater Bridge', type:'road', x:64, y:60, discovered:true},
    {id:'belfry', name:'Hollow Belfry', type:'dungeon', x:86, y:63, discovered:true},
    {id:'ferry', name:'Mourning Reed Ferry', type:'merchant', x:87, y:38, discovered:true},
    {id:'crypt', name:'Sunken Crypt', type:'danger', x:22, y:82, discovered:true},
    {id:'shrine', name:'Greenmother’s Shrine', type:'npc', x:52, y:51, discovered:true},
    {id:'scout', name:'Crowfield Scout', type:'event', x:45, y:43, discovered:true},
    {id:'unknown', name:'Fog-Buried Keep', type:'unknown', x:77, y:13, discovered:false}
  ],
  activeRoute: 'pilgrim'
};
