import { useMemo, useState, useRef } from 'react';
import { MapPin, Tent, Skull, Castle, Store, UserRound, ScrollText, Route, LocateFixed } from 'lucide-react';
import { WORLD } from '../data/world.js';

const iconFor = {
  town: Castle,
  quest: ScrollText,
  ruin: Castle,
  road: Route,
  dungeon: Skull,
  merchant: Store,
  danger: Skull,
  npc: UserRound,
  event: MapPin,
  unknown: MapPin,
};

export function Atlas({ travel, onTravel }) {
  const [zoom, setZoom] = useState(1.1);
  const [pan, setPan] = useState({ x: -8, y: -8 });
  const [selectedRoute, setSelectedRoute] = useState(WORLD.activeRoute);
  const [selectedLoc, setSelectedLoc] = useState('ashmoor');
  const dragRef = useRef(null);

  const activeRoad = WORLD.roads.find(r => r.id === selectedRoute) || WORLD.roads[0];
  const selectedLocation = WORLD.locations.find(l => l.id === selectedLoc) || WORLD.locations[0];

  const progressPoint = useMemo(() => {
    const pts = activeRoad.points;
    const progress = travel?.progress ?? 0.12;
    const idx = Math.min(pts.length - 2, Math.floor(progress * (pts.length - 1)));
    const local = (progress * (pts.length - 1)) - idx;
    const a = pts[idx], b = pts[idx + 1];
    return [a[0] + (b[0] - a[0]) * local, a[1] + (b[1] - a[1]) * local];
  }, [activeRoad, travel]);

  function startDrag(e) {
    const p = e.touches?.[0] || e;
    dragRef.current = { x:p.clientX, y:p.clientY, pan:{...pan} };
  }
  function moveDrag(e) {
    if (!dragRef.current) return;
    const p = e.touches?.[0] || e;
    setPan({ x: dragRef.current.pan.x + (p.clientX-dragRef.current.x)/5, y: dragRef.current.pan.y + (p.clientY-dragRef.current.y)/5 });
  }
  function endDrag(){ dragRef.current = null; }

  return <section className="atlas-wrap">
    <div className="atlas-header-grid">
      <div className="stat-card"><span>Current Location</span><b>Ashmoor Cross</b><small>The Silver Road</small></div>
      <div className="stat-card"><span>Destination</span><b>{selectedLocation.name}</b><small>{selectedLocation.type}</small></div>
      <div className="stat-card"><span>Travel Status</span><b>{travel?.moving ? 'On the road' : 'Planning'}</b><small>ETA {activeRoad.time}</small></div>
      <div className="stat-card"><span>Danger</span><b>{['Low','Low','Moderate','High'][activeRoad.danger]}</b><small>{'☠'.repeat(activeRoad.danger)}{'○'.repeat(4-activeRoad.danger)}</small></div>
    </div>

    <div className="atlas-frame">
      <div className="atlas-controls">
        <button onClick={()=>setZoom(z=>Math.min(2.2,z+.16))}>＋<span>Zoom</span></button>
        <button onClick={()=>setZoom(z=>Math.max(.8,z-.16))}>－<span>Out</span></button>
        <button onClick={()=>{setZoom(1.1); setPan({x:-8,y:-8});}}>⌖<span>Find</span></button>
      </div>
      <div className="compass">N</div>
      <svg className="atlas-svg" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice"
        onMouseDown={startDrag} onMouseMove={moveDrag} onMouseUp={endDrag} onMouseLeave={endDrag}
        onTouchStart={startDrag} onTouchMove={moveDrag} onTouchEnd={endDrag}>
        <defs>
          <filter id="grain"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="4" stitchTiles="stitch"/><feColorMatrix type="saturate" values="0.22"/><feBlend mode="multiply" in2="SourceGraphic"/></filter>
          <filter id="ink"><feDropShadow dx="0" dy="1" stdDeviation=".7" floodColor="#000" floodOpacity=".75"/></filter>
          <linearGradient id="water" x1="0" x2="1"><stop stopColor="#385d61"/><stop offset="1" stopColor="#14323b"/></linearGradient>
          <linearGradient id="paper" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#d8c69a"/><stop offset=".55" stopColor="#9b8a61"/><stop offset="1" stopColor="#43513d"/></linearGradient>
        </defs>
        <g transform={`translate(${pan.x} ${pan.y}) scale(${zoom})`}>
          <rect x="-20" y="-20" width="140" height="140" fill="url(#paper)" filter="url(#grain)"/>
          {WORLD.regions.map(r => <ellipse key={r.id} cx={r.x+r.w/2} cy={r.y+r.h/2} rx={r.w/2} ry={r.h/2} className={`region ${r.tone}`}/>)}
          {WORLD.rivers.map((river,i)=><path key={i} d={line(river)} className="river"/>)}
          {WORLD.roads.map((road)=><path key={road.id} d={line(road.points)} className="road"/>)}
          <path d={line(activeRoad.points)} className="active-route"/>
          {WORLD.mountains.map((m,i)=><g key={i} className="mountain" transform={`translate(${m[0]} ${m[1]}) scale(${m[2]/6})`}><path d="M0 7 L5 -6 L11 7 Z"/><path d="M5 -6 L4 2 L7 2 Z" className="snow"/></g>)}
          {WORLD.forests.map((t,i)=><g key={i} className={t.dense?'tree dense':'tree'} transform={`translate(${t.x} ${t.y}) scale(${t.s})`}><path d="M0 4 L3 -3 L6 4 Z"/><rect x="2.6" y="3" width=".9" height="3"/></g>)}
          {WORLD.locations.map(loc => {
            const Icon = iconFor[loc.type] || MapPin;
            return <g key={loc.id} transform={`translate(${loc.x} ${loc.y})`} className={`map-location ${selectedLoc===loc.id?'selected':''}`} onClick={()=>setSelectedLoc(loc.id)}>
              <circle r="2.4" className={`pin ${loc.type}`}/>
              <foreignObject x="-1.6" y="-1.6" width="3.2" height="3.2"><Icon size={13}/></foreignObject>
              <text x="0" y="5.3">{loc.name}</text>
            </g>
          })}
          <g className="player" transform={`translate(${progressPoint[0]} ${progressPoint[1]})`}><circle r="2.6"/><circle r="4.3"/></g>
          <g className="region-labels">
            {WORLD.regions.map(r=><text key={r.id} x={r.x+r.w/2} y={r.y+r.h/2}>{r.name}</text>)}
          </g>
        </g>
        <rect x="0" y="0" width="100" height="100" className="vignette"/>
      </svg>
    </div>
    <div className="route-panel">
      {WORLD.roads.map(r=><button key={r.id} className={selectedRoute===r.id?'route-choice active':'route-choice'} onClick={()=>setSelectedRoute(r.id)}>
        <b>{r.name}</b><span>{r.time}</span><small>{r.reward}</small><em>{'☠'.repeat(r.danger)}{'○'.repeat(4-r.danger)}</em>
      </button>)}
    </div>
    <button className="primary" onClick={()=>onTravel(activeRoad)}>Start Travel</button>
  </section>
}

function line(points){ return 'M '+points.map(p=>p.join(' ')).join(' L '); }
