# Loot & Legends GitHub Pages Project

This is the clean no-Codex baseline. Upload the extracted files to the root of the `salescout2026/pieceXpieceV1` repository.

## GitHub Pages
The workflow `.github/workflows/deploy-pages.yml` builds the Vite app and deploys `dist` to GitHub Pages.

Repo URL after deploy:
https://salescout2026.github.io/pieceXpieceV1/

## Local test
```bash
npm install
npm run dev
```
